import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { CompanyComponent } from './company/company.component';
import { StocksComponent } from './stocks/stocks.component';

const routes: Routes = [
  {path: '', component: WelcomeComponent, title: 'SSE - Welcome'},
  {path: 'company', component: CompanyComponent, title: 'SSE - Company',
    children:[{path: 'stocks', component: StocksComponent, title: 'SSE - Stocks'}]}
  ,
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
