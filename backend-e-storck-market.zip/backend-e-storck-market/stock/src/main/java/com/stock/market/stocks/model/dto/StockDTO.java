package com.stock.market.stocks.model.dto;

import com.stock.market.stocks.model.Stock;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;


@Data
@NoArgsConstructor
public class StockDTO {

    private String companyCode;
    private Double price;
    private LocalDate creationDate;
    private LocalTime creationTime;

    public StockDTO(Stock stock) {
        this.companyCode = stock.getCompanyCode();
        this.price = stock.getPrice();
        this.creationDate = stock.getInsertTime().toLocalDate();
        this.creationTime = stock.getInsertTime().toLocalTime();
    }

    public List<StockDTO> getStockDTOs(List<Stock> stocks) {

        return stocks.stream()
                .map(s->new StockDTO(s))
                .collect(toList());
    }
}