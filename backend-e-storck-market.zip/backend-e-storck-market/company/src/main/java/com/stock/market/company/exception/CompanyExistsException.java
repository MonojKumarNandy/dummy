package com.stock.market.company.exception;

public class CompanyExistsException extends RuntimeException {
    public CompanyExistsException(String message){super(message);}
}
