package com.stock.market.company.exception;

public class CompanyNotFoundException extends RuntimeException {
    public CompanyNotFoundException(String message){super(message);}
}
