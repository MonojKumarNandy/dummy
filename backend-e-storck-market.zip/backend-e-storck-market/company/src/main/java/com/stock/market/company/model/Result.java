package com.stock.market.company.model;

import lombok.Builder;
import lombok.Data;


@Builder
@Data
public class Result {

    String result;
}