export class Company {
    public companyCode: string;
    public companyName: string;
    
    constructor(companyCode: string, companyName: string) {
        this.companyCode = companyCode;
        this.companyName = companyName;
    }

    getCompanyName(): string {
        return `${this.companyName}`;
    }

    getCompanyCode(): string {
        return `${this.companyCode}`;
    }
}