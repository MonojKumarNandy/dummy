import { Stock } from "./stock";

export class StockSearch {
    public stocks: Stock[];
    public minPrice: number;
    public maxPrice: number;
    public avgPrice: number;

    constructor(stocks: Stock[], minPrice: number, maxPrice: number, avgPrice: number) {
        this.stocks = stocks;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.avgPrice = avgPrice;
    }
}