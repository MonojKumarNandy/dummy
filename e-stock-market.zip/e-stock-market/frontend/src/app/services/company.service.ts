import { Injectable } from '@angular/core';
import { Company } from "./company";
import { HttpClient } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { StockSearch } from './stockSearch';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable()
export class CompanyService {
    private findAllUrl: string = '';
    private findByCodeStartEndDateUrl: string = '';

    constructor(private http: HttpClient, private snackbar: MatSnackBar) {

    }

    findAll(): Observable<any> {
        this.findAllUrl = 'http://ec2-54-242-186-82.compute-1.amazonaws.com:8443/api/v1.0/market/company/getall'; //host and port need to be modified
        return this.http.get<Company[]>(this.findAllUrl).pipe();
    }

    findStocks(code: string, startDate: String, endDate: String): Observable<any> {
        this.findByCodeStartEndDateUrl = 'http://ec2-54-242-186-82.compute-1.amazonaws.com:8094/api/v1.0/market/stock/get/' + code + '/' + startDate + '/' + endDate; //host and port need to be modified
        return this.http.get<StockSearch>(this.findByCodeStartEndDateUrl).pipe(retry(1), catchError(this.handleError));
    }

    handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        
        this.snackbar.open("No Records Found", "Done");
        return throwError(() => {
            return errorMessage;
        });
    }
}