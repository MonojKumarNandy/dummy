export class Stock {
    public companyCode: string;
    public creationDate: string
    public creationTime: string;
    public price: number;

    constructor(companyCode: string, creationDate: string, creationTime: string, price: number) {
        this.companyCode = companyCode;
        this.price = price;
        this.creationDate = creationDate;
        this.creationTime = creationTime;
    }

    getStockPrice(): string {
        return `${this.price}`;
    }

    getCompanyCode(): string {
        return `${this.companyCode}`;
    }

    getDate(): string {
        return `${this.creationDate}`;
    }

    getTime(): string {
        return `${this.creationTime}`;
    }
}