import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MaterialModule } from './material.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CompanyComponent } from './company/company.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { SharedModule } from './shared.module';
import { HttpClientModule } from '@angular/common/http';
import { CompanyService } from './services/company.service';
import { DatePipe } from '@angular/common';
import { StocksComponent } from './stocks/stocks.component';

@NgModule({
  declarations: [
    AppComponent,
    CompanyComponent,
    WelcomeComponent,
    StocksComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    HttpClientModule,
  ],
  providers: [CompanyService, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
