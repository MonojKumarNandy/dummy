import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { Company } from '../services/company';
import { CompanyService } from '../services/company.service';
import { Stock } from '../services/stock';
import { DatePipe } from '@angular/common';
import { StockSearch } from '../services/stockSearch';
import { Router } from '@angular/router';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  public companies: Company[] = [];
  public company!: Company;
  public selectedCode: string = '';
  public stock: Stock[] = [];
  public stockDetails!: Stock;
  public stockSearch!: StockSearch;
  range = new FormGroup({
    start: new FormControl<Date | null>(null,[ Validators.required ]),
    end: new FormControl<Date | null>(null,[ Validators.required ]),
  });
  constructor(private companyService: CompanyService, private datePipe: DatePipe, private readonly router : Router) {
  }

  ngOnInit() {
    const ob = this.companyService.findAll();
    ob.subscribe(data => {
      this.companies = data;
    });
  }
  onSubmit() {
    let startDate = this.datePipe.transform(this.range.controls.start.value, 'yyyy-MM-dd');
    let endDate = this.datePipe.transform(this.range.controls.end.value, 'yyyy-MM-dd');
    const ob = this.companyService.findStocks(this.selectedCode, startDate?startDate:'', endDate?endDate:'');
    ob.subscribe(data => {
      this.stockSearch = data;
      this.stock = this.stockSearch.stocks;
         
    });
  }

}
