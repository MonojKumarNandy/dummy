import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  constructor() { }
  slides = [
    {'image': 'https://www.thetimes.co.uk/imageserver/image/%2Fmethode%2Ftimes%2Fprod%2Fweb%2Fbin%2Fa1a0bc38-1512-11eb-9859-b09ba5b6a3c4.jpg'},
    {'image': 'https://img.freepik.com/premium-photo/exterior-new-york-stock-exchange-wall-street-lower-manhattan-new-york-city-usa_561846-52.jpg'},
    {'image': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/BSE_building_at_Dalal_Street.JPG/800px-BSE_building_at_Dalal_Street.JPG'}
  ];
  ngOnInit(): void {
    
  }

}
