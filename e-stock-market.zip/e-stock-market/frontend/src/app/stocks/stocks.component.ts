import { Component, OnInit, Input } from '@angular/core';
import { Stock } from '../services/stock';
import { StockSearch } from '../services/stockSearch';

@Component({
  selector: 'app-stocks',
  templateUrl: './stocks.component.html',
  styleUrls: ['./stocks.component.css']
})
export class StocksComponent implements OnInit {

  constructor() { }
  
  @Input() public stock!: Stock[] ;
  @Input() public stockDetails!: Stock;
  @Input() public stockSearch!: StockSearch;
 
  displayedColumns = ["price", "creationDate", "creationTime"];
  ngOnInit(): void {
  }

}
