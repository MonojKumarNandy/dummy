package com.stock.market.stocks.service;

import com.stock.market.stocks.exception.NoDataFoundException;
import com.stock.market.stocks.model.Stock;
import com.stock.market.stocks.model.StockSearch;
import com.stock.market.stocks.repository.StockDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
public class StockServiceTest {

    @Mock
    StockDao stockDao;

    @InjectMocks
    private StockServiceImpl stockService;

    @Test
    public void testGetStocks() {
        Stock st = new Stock();
        st.setInsertTime(LocalDateTime.now());
        st.setPrice(1234D);
        List<Stock> stockList = new ArrayList<>();
        stockList.add(st);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate startDt = LocalDate.parse("2022-10-10", formatter);
        LocalDate endDt = LocalDate.parse("2022-10-16", formatter).plusDays(1);
        Mockito.when(stockDao.findByCompanyCodeAndInsertTimeBetween("asd", startDt.atStartOfDay(), endDt.atStartOfDay())).thenReturn(stockList);
        StockSearch stk = stockService.getStocks("asd", "2022-10-10", "2022-10-16");
        assertEquals("1234.0", stk.getAvgPrice().toString());
    }

    @Test(expected = NoDataFoundException.class)
    public void testGetStocksException() {
        List<Stock> stockList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate startDt = LocalDate.parse("2022-10-10", formatter);
        LocalDate endDt = LocalDate.parse("2022-10-16", formatter).plusDays(1);
        Mockito.when(stockDao.findByCompanyCodeAndInsertTimeBetween("asd", startDt.atStartOfDay(), endDt.atStartOfDay())).thenReturn(stockList);
        stockService.getStocks("asd", "2022-10-10", "2022-10-16");
    }


}
