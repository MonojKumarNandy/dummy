package com.stock.market.stocks.controller;

import com.stock.market.stocks.exception.CompanyNotFoundException;
import com.stock.market.stocks.exception.NoDataFoundException;
import com.stock.market.stocks.model.Stock;
import com.stock.market.stocks.model.StockSearch;
import com.stock.market.stocks.model.dto.StockDTO;
import com.stock.market.stocks.service.StockService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
public class StockControllerTest {

    @Mock
    private StockService stockService;

    @InjectMocks
    private StockController stockControllers;

    @Test
    public void testAddStock() {
        Stock st = new Stock();
        st.setInsertTime(LocalDateTime.now());
        Mockito.when(stockService.addStock(st, "asd")).thenReturn(st);
        ResponseEntity<StockDTO> stk = stockControllers.addStock(st, "asd");
        assertEquals(200, stk.getStatusCode().value());
    }

    @Test
    public void testAddStock400() {
        Stock st = new Stock();
        st.setInsertTime(LocalDateTime.now());
        Mockito.when(stockService.addStock(st, "asd")).thenThrow(new CompanyNotFoundException("Company Not found"));
        ResponseEntity<StockDTO> stk = stockControllers.addStock(st, "asd");
        assertEquals(400, stk.getStatusCode().value());
    }

    @Test
    public void testGetStocks() {
        Mockito.when(stockService.getStocks("asd", "2022-10-10", "2022-10-16")).thenReturn(StockSearch.builder().build());
        ResponseEntity<StockSearch> stk = stockControllers.getStock("asd", "2022-10-10", "2022-10-16");
        assertEquals(200, stk.getStatusCode().value());
    }

    @Test
    public void testGetStocks400() {
        Mockito.when(stockService.getStocks("asd", "2022-10-10", "2022-10-16")).thenThrow(new NoDataFoundException("No data Found"));
        ResponseEntity<StockSearch> stk = stockControllers.getStock("asd", "2022-10-10", "2022-10-16");
        assertEquals(400, stk.getStatusCode().value());
    }

}
