package com.stock.market.stocks.exception;

public class CompanyExistsException extends RuntimeException {
    public CompanyExistsException(String message){super(message);}
}
