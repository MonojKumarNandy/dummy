package com.stock.market.stocks.exception;

public class CompanyNotFoundException extends RuntimeException {
    public CompanyNotFoundException(String message){super(message);}
}
