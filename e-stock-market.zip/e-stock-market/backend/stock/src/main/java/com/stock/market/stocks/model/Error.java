package com.stock.market.stocks.model;

import lombok.Builder;
import lombok.Data;


@Builder
@Data
public class Error {

    String result;
}