package com.stock.market.company.exception;

public class InvalidStructureException extends RuntimeException {
    public InvalidStructureException(String message){super(message);}
}
