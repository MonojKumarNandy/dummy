# e-stockmarket

Company-service endpoint :- http://ec2-54-242-186-82.compute-1.amazonaws.com:8443/api/v1.0/market/company/register
Stock-service endpoint   :- http://ec2-54-242-186-82.compute-1.amazonaws.com:8094/actuator/health

UI-Endpoint :- http://stk-mkt-frntend.s3-website.us-east-2.amazonaws.com/